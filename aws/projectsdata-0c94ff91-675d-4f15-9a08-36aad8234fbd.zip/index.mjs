// export const handler = async (event) => {
//   // TODO implement
//   const response = {
//     statusCode: 200,
//     body: JSON.stringify('Hello from Lambda!'),
//   };
//   return response;
// };


// Assuming this Lambda function is in the same directory as your data file
import projectsData from './projectsData.js';

export const handler = async (event) => {
  const projects = projectsData.map((project) => {
    return {
      id: project.id,
      img: project.img,
      name: project.name,
      description: project.description,
      langs: project.langs,
      tools: project.tools,
      details: project.details,
    };
  });

  const response = {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
    },
    body: JSON.stringify(projects),
  };
  return response;
};
